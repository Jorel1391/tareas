/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helpers;

/**
 *
 * @author Jorge Elvir
 */
public class Linea extends Formas{
    private String largo;
    public Linea(String dibujar, String color, String largo){
    super(dibujar, color);
    this.largo = largo;
    
    }
    
   public void mostrarDatos(){
        
        System.out.println("La forma es: " + obDibujar()+
                "/ El largo de la linea es; " + largo+
                "/ El color de la linea es: " + obColor());
        
    }
    @Override
    public String obtenerInfo(){
     return "informacion de Linea";   
    }
    
}
