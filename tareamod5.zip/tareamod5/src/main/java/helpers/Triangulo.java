/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helpers;

/**
 *
 * @author Jorge Elvir
 */
public class Triangulo extends Formas{
    
    private String angulo;
    public Triangulo(String dibujar,String color,String angulo){
        super(dibujar, color);
        this.angulo = angulo;      
           
    }
    public void mostrarDatos(){
        
        System.out.println("La forma es: " + obDibujar()+
                "/ La suma de los angulos de un triangulo es" + angulo+
                "/ El color del triangulo es: " + obColor());
        
    }
    @Override
    public String obtenerInfo(){
     return "informacion del triangulo";   
    }
}
