/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helpers;

/**
 *
 * @author Jorge Elvir
 */
public class Cuadrado extends Formas{
    
   private String area;
    public Cuadrado(String dibujar, String color, String area){
        super(dibujar, color);
        this.area = area;      
           
    }
    public void mostrarDatos(){
        
        System.out.println("La forma es: " + obDibujar()+
                "/ La formula del area: " + area+
                "/ El color del cuadrado es: " + obColor());
        
    }
   @Override
    public String obtenerInfo(){
     return "informacion del cuadrado";   
    }
    
}
