/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helpers;

/**
 *
 * @author Jorge Elvir
 */
public abstract class Formas {
    
    private String color;
    private String dibujar;
    
    public Formas(String dibujar, String color){           
        this.dibujar = dibujar; 
        this.color = color;
    }
    
    public void estColor(String color){
        this.color = color;
        
           
    }
    public void estDibujar(String dibujar){
        
        this.dibujar = dibujar;
           
    }
    
     public String obDibujar(){
        
       return dibujar ;
           
    }
     public String obColor(){
        
       return color ;
           
    }
     
     
     abstract String obtenerInfo();
     
}
