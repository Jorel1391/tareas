/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helpers;

/**
 *
 * @author Jorge Elvir
 */
public class Circulo extends Formas {
    private String radio;
    public Circulo(String dibujar, String color, String radio){
        super(dibujar, color);
        this.radio = radio;
               
    }
    
    public void mostrarDatos(){
        
        System.out.println("la forma es: " + obDibujar()+
                "/ La formula del radio " + radio+
                "/ El color del circulo es: " + obColor());
        
    }
    @Override
    public String obtenerInfo(){
     return "informacion del circulo";   
    }
}
