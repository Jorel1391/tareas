/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.tareamod5;

import helpers.Circulo;
import helpers.Cuadrado;
import helpers.Linea;
import helpers.Triangulo;

/**
 *
 * @author Jorge Elvir
 */
public class tareamodulo5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Linea linea = new Linea("Linea","Azul","10o cm");
        Circulo circulo = new Circulo("Circulo","Rojo","a=2piR^2");
        Triangulo triangulo = new Triangulo("Triangulo","Amarillo","180");
        Cuadrado cuadrado = new Cuadrado("Cuadrado","Verde","a=bxh");
        
        System.out.println(linea.obtenerInfo());
        linea.mostrarDatos();
        System.out.println(circulo.obtenerInfo());
        circulo.mostrarDatos();
        System.out.println(triangulo.obtenerInfo());
        triangulo.mostrarDatos();
        System.out.println(cuadrado.obtenerInfo());
        cuadrado.mostrarDatos();
        
    }
    
}
