/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.tareamod4;

import helpers.Doctor;
import helpers.HospitalAtlantida;
import helpers.HospitalEscuela;
import helpers.HospitalRivas;

/**
 *
 * @author Jorge Elvir
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Doctor doctor = new Doctor("Manuel");
        
        doctor.impNombre();
        
        doctor.estEdad(30);
        doctor.estAniosexp(10);
         
        System.out.println("la edad del doctor es: "+ doctor.obtenerEdad());
        System.out.println("los años de esperiencia son: "+ doctor.obtenerAniosexp());
        
        
        //instanciar las clases 
        HospitalEscuela he = new HospitalEscuela();
        HospitalRivas hr = new HospitalRivas();
        HospitalAtlantida ha = new HospitalAtlantida ();
        
        System.out.println("El nombre del hospital de Tegucigalpa es: " + he.getPais());
        System.out.println("El nombre del director del hospital Escuela es:" + he.getDirector());
        
        System.out.println("El nombre del hospital de San Pedro Sula es: " + hr.getPais());
        System.out.println("El nombre del director del hospital Mario Catarino Rivas es:" + hr.getDirector());
        
        System.out.println("El nombre del hospital de La Ceiba es: " + ha.getPais());
        System.out.println("El nombre del director del hospital Atlantida es:" + ha.getDirector());
        
        
    }
    
}
