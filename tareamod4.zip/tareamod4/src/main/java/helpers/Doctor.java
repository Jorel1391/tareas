/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helpers;

/**
 *
 * @author Jorge Elvir
 */

public class Doctor {
    
    //declaramos variables privadas
    private String nombre;
    private int edad;
    private int aniosexp;
    
    public Doctor(String nombre) {
    this.nombre = nombre;  
        
    }
    public void impNombre() {
    System.out.println("El nombre del doctor es "+ nombre);  
        
    }
    public void estEdad(int _edad) {
    this.edad = _edad;  
        
    }
    public void estAniosexp(int _aniosexp) {
    this.aniosexp = _aniosexp;  
        
    }
    public int obtenerEdad() {
    return edad;  
        
    }
    public int obtenerAniosexp() {
    return aniosexp;  
        
    }
    
    
}